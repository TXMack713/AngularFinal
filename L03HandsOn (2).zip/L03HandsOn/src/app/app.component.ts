import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Anthony T. Mack';
  city = 'Oconomowoc';
  tagline = 'Excellence is Standard';
  about_me = 'Native Texan loving Jesus, my gorgeous wife and our adorable kids while learning to code in Wisconsin.';
}

/*
Lesson 3 HandsOn Practice Sample Solution

import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Mr. Bigglesworth';
  city = 'New York';
  tagline = 'Meow all day every day';
  aboutMe = 'I am a city cat. I live with my humans in a beautiful apartment. I spend my time looking out the window, eating, and sleeping on my luxurious bed. My lovely, long white fur is brushed daily, so I am always looking my best.'
}

*/