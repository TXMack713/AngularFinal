import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { Task } from './task';

@Injectable({
  providedIn: 'root'
})
export class TaskDataService {

  public tasksRoute = 'http://localhost:3000/tasks';
  public tasks: Task[];

  getTasks = (): Observable<Task[]> => {
    return this.http.get<Task[]>(this.tasksRoute);
  }

  getTask = (id: number): Observable<Task> => {
    return this.http.get<Task>(this.tasksRoute + '/' + id);
  }

  addTask = (task: Task): Observable<Task> => {
    return this.http.post<Task>(this.tasksRoute, task);
  }

  deleteTask = (id: number): Observable<Task> => {
    return this.http.delete<Task>(this.tasksRoute + '/' + id);
  }

  editTask = (task: Task): Observable<Task> => {
    return this.http.put<Task>(this.tasksRoute + '/' + task.id, task);
  }
  constructor(private http: HttpClient) { }
}
