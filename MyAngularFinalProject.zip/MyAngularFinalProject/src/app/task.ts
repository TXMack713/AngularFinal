export class Task {
    id: number;
    title: string;
    timeToComplete: number;
    description: string;
    itemsNeeded: string;
}
