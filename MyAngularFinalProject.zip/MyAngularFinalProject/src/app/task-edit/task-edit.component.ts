import { Component, OnInit } from '@angular/core';
import { TaskDataService } from '../task-data.service';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { Task } from '../task';

@Component({
  selector: 'app-task-edit',
  templateUrl: './task-edit.component.html',
  styleUrls: ['./task-edit.component.css']
})
export class TaskEditComponent implements OnInit {

  editTask: Task = new Task();

  public tasks: Task[];

  saveTask = () => {
    this.taskDataService.editTask(this.editTask).subscribe(task =>
      this.router.navigate(['list']));
  }

   // Get the list of tasks from the JSON mock database
  getTasks = (): void => {
    this.taskDataService.getTasks().subscribe(tasks => this.tasks = tasks);
  }

  // getTask = (id: number): void => {
  //   this.taskDataService.getTask(id).subscribe(tasks => this.tasks = tasks);
  // }

  // Delete the selected task from the list of tasks on the JSON mock database
  deleteTask = (id: number): void => {
    // let myIndex = 0;
    // for (const task of this.tasks) {
    //   if (task.id === id) {
    //     this.tasks.pop(myIndex, 1);
    //     break;
    //   }
    //   myIndex++;
    // }
    this.taskDataService.deleteTask(id).subscribe(
      tasks => this.tasks.pop[id]);
  }

  constructor(
    private taskDataService: TaskDataService,
    private router: Router,
    private route: ActivatedRoute
    ) { }

  ngOnInit() {
    this.route.params.subscribe(param => {
      this.taskDataService.getTask(+param['id'])
      .subscribe(tasks => (this.editTask = tasks));
    });
  }
}

