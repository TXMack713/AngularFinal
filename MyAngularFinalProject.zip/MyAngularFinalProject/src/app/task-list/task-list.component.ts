import { Component, OnInit } from '@angular/core';
import { Task } from '../task';
import { TaskDataService } from '../task-data.service';
// import { timingSafeEqual } from 'crypto';

@Component({
  selector: 'app-task-list',
  templateUrl: './task-list.component.html',
  styleUrls: ['./task-list.component.css']
})
export class TaskListComponent implements OnInit {
  public tasks: Task[];

 // Get the list of tasks from the JSON mock database
 getTasks = (): void => {
   this.taskDataService.getTasks().subscribe(tasks => this.tasks = tasks);
 }

 // Delete the selected task from the list of tasks on the JSON mock database
 deleteTask = (id: number): void => {
   this.taskDataService.deleteTask(id).subscribe(
     tasks => this.getTasks());
 }

  constructor(private taskDataService: TaskDataService) { }

  ngOnInit() {
    this.getTasks();
  }

}
