export class Music {
    id: number;
    title: string;
    artist: string;
    url: string;
}
