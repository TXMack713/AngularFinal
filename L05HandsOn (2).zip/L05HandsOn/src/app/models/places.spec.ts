import { Places } from './places';

describe('Places', () => {
  it('should create an instance', () => {
    expect(new Places()).toBeTruthy();
  });
});
