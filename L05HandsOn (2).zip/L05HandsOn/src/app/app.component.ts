import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Anthony T. Mack';
  city = 'Oconomowoc';
  tagline = 'Excellence is Standard';
  about_me = "I'm a native Texan from northeast Houston. I was the first in my immediate family to attend and graduate college. I have a B.S. in Mechanical Engineering from Prairie View A&M University. I'm a happily married father of 4 with an affinity for faith, family, food and fun. I'm currently pursuing my passion for Software Engineering with the Bethel School of Technology and look forward to making an impact in tech!";
}
