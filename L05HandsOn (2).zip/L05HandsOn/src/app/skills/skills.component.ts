import { Component, OnInit } from '@angular/core';
import { Skill } from '../models/skill';

import { SkillsService } from '../services/skills.service';

@Component({
  selector: 'app-skills',
  templateUrl: './skills.component.html',
  styleUrls: ['./skills.component.css']
})
export class SkillsComponent implements OnInit {
  skills: Skill[];
  dataService: SkillsService;

  constructor(private skillsService: SkillsService) {
    this.dataService = this.skillsService;
  }

  ngOnInit(): void {
    // this.skills = this.dataService.skills; //Changing how the data is being sent, this method allows for a one-time copy
    // This method provides for an ongoing update as the database updates
    // observable = this.dataService.getSkills()
    this.dataService.getSkills().subscribe(skills => this.skills = skills);
  }

}
