import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { AppComponent } from '../app/app.component';
import { SkillsComponent } from './skills/skills.component';

import { SkillsService } from './services/skills.service';
import { ContactComponent } from './contact/contact.component';
import { ContactService } from './services/contact.service';
import { GreetingComponent } from './greeting/greeting.component';
import { MessageFormComponent } from './message-form/message-form.component';
import { FavoritePlacesComponent } from './favorite-places/favorite-places.component';
import { PlaceFormComponent } from './place-form/place-form.component';
import { PlacesService } from './services/places.service';

@NgModule({
  declarations: [
    AppComponent,
    SkillsComponent,
    ContactComponent,
    GreetingComponent,
    MessageFormComponent,
    FavoritePlacesComponent,
    PlaceFormComponent
  ],
  imports: [BrowserModule, FormsModule],
  // add SkillService to the providers array:
  providers: [SkillsService, ContactService, PlacesService],
  bootstrap: [AppComponent]
})
export class AppModule { }
