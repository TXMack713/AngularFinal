import { Injectable } from '@angular/core';

import { Skill } from '../models/skill';
import { Level } from '../types/level.enum';

@Injectable({
  providedIn: 'root'
})
export class SkillsService {
  skills: Skill[] = [
    {
      id: 0,
      name: 'Mechanical Engineering',
      level: Level.Advanced
    },
    {
      id: 1,
      name: '3D and 2D CAD',
      level: Level.Advanced
     },
     {
       id: 2,
       name: 'Troubleshooting',
       level: Level.Advanced
      },
      {
        id: 3,
        name: 'Technical Writing',
        level: Level.Intermediate
      },
      {
        id: 4,
        name: 'Public Speaking',
        level: Level.Intermediate
      },
      {
        id: 5,
        name: 'Software Development',
        level: Level.Beginner
      }
    ];

  constructor() { }
}
