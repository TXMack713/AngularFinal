export class Message {
    name: string;
    email: string;
    subject: string;
    message: string;
}
